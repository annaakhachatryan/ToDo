import React from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import { Comments } from '../../pages/Comments/Comments'
import { Layout } from '../../pages/Layout/Layout'
import { Posts } from '../../pages/Posts/Posts'
import { Photos } from '../../pages/Photos/Photos'
import { Post } from '../Post/Post'
import { Photo } from '../Photo/Photo'
import { Comment } from '../Comment/Comment'
import { Users } from '../../pages/Users/Users'
import { ToDos } from '../../pages/ToDos/ToDos'
import { User } from '../User/User'
import { ToDo } from '../ToDo/ToDo'
import { NewUsers } from '../../pages/New/NewUsers'
import { Address } from '../Address/Address'

export const AppRouter = () => {
    return (
        <div>
            <Routes>
                <Route path='/' element={<Layout />}>
                    <Route index element={<Posts />} />
                    <Route path='PostsName' element={<Navigate to='/' />} />
                    <Route path='/:id' element={<Post />} />
                    <Route path='Photos' element={<Photos />} />
                    <Route path='Photos/:id' element={<Photo />} />
                        <Route path='New/' element={<NewUsers />}>
                            <Route path='user' element={<Users />} />
                            <Route path='user/:id' element={<User />} />
                            <Route path='user/:id/:id' element={<Address />} />
                            <Route path='todo' element={<ToDos />} />
                            <Route path='todo/:id' element={<ToDo />} />
                            <Route path='*' element={<h1>Not Found</h1>} />
                        </Route>
                    <Route path='Comments' element={<Comments />} />
                    <Route path='Comments/:id/' element={<Comment />} />
                    <Route path='*' element={<h1>Not Found</h1>} />
                </Route>
            </Routes>
        </div>
    )
}
