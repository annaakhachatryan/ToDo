import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router'

export const ToDo = () => {
    const [toDo, setToDo] = useState({})
    const { id } = useParams()
    const navigate = useNavigate()

    useEffect(() => {
        fetch(`https://jsonplaceholder.typicode.com/todos/${id}`)
        .then(res=>res.json())
        .then(data=>setToDo(data))
    }, [id])
    return (
        <div style={{display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column'}}>
            <button onClick={() => navigate(-1)} className='back'>Back</button>
            <div className='eachItem'>
                <p><span>ID :</span> {toDo.id}</p>
                <p><span>title :</span> {toDo.title}</p>
                <p><span>userId :</span> {toDo.userId}</p>
            </div>
        </div>
    )
}
