import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router'
import './Post.css'
export const Post = () => {
    const [post, setPost] = useState({})
    const {id} = useParams()
    const navigate = useNavigate()

    useEffect(() => {
            fetch(`https://jsonplaceholder.typicode.com/posts/${id}`)
            .then(res => res.json())
            .then(data => setPost(data))
    }, [id])
    return (
        <div style={{display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column'}}>
            <button className='back' onClick={()=>navigate(-1)}>Back</button>
            <div className='eachItem'>
                <p><span>ID :</span> {post.id}</p>
                <p><span>UserId :</span> {post.userId}</p>
                <p><span>Title :</span> {post.title}</p>
                <p><span>Body : </span>{post.body}</p>
            </div>
        </div>
    )
}
