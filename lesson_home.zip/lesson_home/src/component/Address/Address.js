import React from 'react'

export const Address = ({address}) => {
    const { city, street, suite, geo } = address
    return (
        <div>
            <p><span>City :</span> {city}</p>
            <p><span>Street :</span> {street}</p>
            <p><span>Suite :</span> {suite}</p>
            <p><span>Geo</span></p>
            <p><span>Lat :</span> {geo.lat}</p>
            <p><span>Long :</span> {geo.lng}</p>
        </div>
    )
}
