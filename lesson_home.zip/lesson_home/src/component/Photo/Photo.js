import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router'

export const Photo = () => {
    const [photo, setPhoto] = useState({})
    const {id} = useParams()
    const navigate = useNavigate()

    const back = () =>{
        navigate(-1)
    }

    useEffect(()=>{
        fetch(`https://jsonplaceholder.typicode.com/photos/${id}`)
        .then(res=>res.json())
        .then(data=>setPhoto(data))
    },[id])
    return (
        <div style={{display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column'}}>
            <h1>Photo</h1>
            <button className='back' onClick={back}>Back</button>
            <div className='eachItem'>
                <p><span>AlbumId :</span> {photo.albumId}</p>
                <p><span>Title :</span> {photo.title}</p>
                <p><span>ID :</span> {photo.id}</p>
                <p><span>URL : </span> <img style={{width:"70px"}} src={photo.url} alt=''/></p>
                <p><span>ThumbnailUrl : </span><img style={{width:"70px"}} src={photo.thumbnailUrl} alt=''/></p>
            </div>
        </div>
    )
}
