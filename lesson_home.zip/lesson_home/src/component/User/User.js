import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router'
import { Link } from 'react-router-dom'
import { Address } from '../Address/Address'

export const User = () => {
    const [user, setUser] = useState({})
    const { id } = useParams()
    const navigate = useNavigate()

    useEffect(() => {
        fetch(`https://jsonplaceholder.typicode.com/users/${id}`)
            .then(res => res.json())
            .then(data => setUser(data))
    }, [id])

    return (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }}>
            <button onClick={() => navigate(-1)} className='back'>Back</button>
            <div className='eachItem'>
                <p><span>ID :</span> {user.id}</p>
                <p><span>Name :</span> {user.name}</p>
                <p><span>username :</span> {user.username}</p>
                <p><span>email :</span> {user.email}</p>
                <p><span>phone :</span> {user.phone}</p>
                <p><span>website :</span> {user.website}</p>
                <Link to={`${user.id}`}>Address</Link>
                {/* <Address address={user.address}/> */}
            </div>
        </div>
    )
}
