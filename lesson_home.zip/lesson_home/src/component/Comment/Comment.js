import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router'

export const Comment = () => {
    const navigate = useNavigate()

    const [comment, setComment] = useState({})
    const {id} = useParams()

    useEffect(()=>{
        fetch(`https://jsonplaceholder.typicode.com/comments/${id}`)
        .then(res=>res.json())
        .then(data => setComment(data))
    }, [id])
    return (
        <div style={{display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column'}}>
            <button onClick={()=>navigate(-1)} className='back'>Back</button>
            <div className='eachItem'>
                <h3> <span>ID : </span>{comment.id}</h3>
                <p><span>PostId : </span>{comment.postId}</p>
                <p><span>Name : </span>{comment.name}</p>
                <p><span>Email : </span>{comment.email}</p>
                <p><span>Body : </span>{comment.body}</p>
            </div>
        </div>
    )
}
