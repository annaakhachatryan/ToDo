import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'

export const Photos = () => {
    const [photos, setPhotos] = useState([])
    const navigate = useNavigate()

    useEffect(() => {
        const getPhotos = async () => {
            const result = await fetch('https://jsonplaceholder.typicode.com/photos?_limit=100')
            const jsonRes = await result.json()

            const data = [
                ...jsonRes.map(el => ({
                    albumId: el.albumId,
                    id: el.id,
                    title: el.title,
                    url: el.url,
                    thumbnailUrl: el.thumbnailUrl
                }))
            ]
            setPhotos(data)
        }
        getPhotos()
    }, [])
    console.log(photos);
    return (
        <div className='postsBigDiv'>
            <h1>Photos</h1>
            <button className='back' onClick={() => navigate(-1)}>Back</button>
            {
                photos.map(element =>
                    <div className='postsDiv' key={element.id} >
                        <div className='item'>
                            <div style={{
                                display: 'flex',
                                flexDirection: 'column',
                                justifyContent:"center",
                                alignItems:"center",
                                padding: '10px',
                                margin: '10px'
                            }}>
                                <h2>{element.id}</h2>
                                <p>{element.albumId}</p>
                                <Link to={`${element.id}`}>{element.title}</Link>
                                <img style={{width:"70px", margin:"20px"}} src={element.url} alt=''/>
                                <img style={{width:"70px", margin:"20px"}} src={element.thumbnailUrl} alt=''/>
                            </div>
                        </div>
                    </div>
                )
            }
        </div>
    )
}
