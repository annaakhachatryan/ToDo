import React from 'react'
import { Link, Outlet } from 'react-router-dom'

export const UserLayout = () => {
    return (
        <div>
            <div className='newUsers'>
                <Link to='user'>User</Link>
                <Link to='todo'>TODO</Link>
            </div>
            <Outlet />
        </div>
    )
}
