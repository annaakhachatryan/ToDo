import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

export const Users = () => {
    const [users, setUsers] = useState([])
    useEffect(() => {
        fetch('https://jsonplaceholder.typicode.com/users')
            .then(res => res.json())
            .then(data => setUsers(data))
    }, [])
    return (
        <div style=
            {{
                display:'flex',
                alignItems:'center', 
                justifyContent:'center', 
                flexDirection:'column',
                marginTop:"8vh"
            }}
            >
            {
                users.map(el =>
                    <div className='eachItem' key={el.id}>
                        <div>
                            <h2>{el.id}</h2>
                            <Link to={`${el.id}`}>{el.name}</Link>
                            <p>{el.username}</p>
                        </div>
                    </div>
                )
            }
        </div>
    )
}
