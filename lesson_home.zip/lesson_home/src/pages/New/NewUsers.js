import React from 'react'
import {UserLayout} from '../../pages/UsersLayout/UserLayout'

export const NewUsers = () => {
    return (
        <div>
            <UserLayout/>
        </div>
    )
}
