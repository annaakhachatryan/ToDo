import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router'
import { Link } from 'react-router-dom';

import './Posts.css'
export const Posts = () => {
    const navigate = useNavigate();
    const [posts, setPosts] = useState([])

    const back=()=>{
        navigate(-1)
    }

    useEffect(()=>{
        const get = async () =>{
            const result = await fetch('https://jsonplaceholder.typicode.com/posts')
            const jsonRes = await result.json()

            const data =[
                ...jsonRes.map(elm=>({
                    id:elm.id,
                    userId:elm.userId,
                    title:elm.title,
                    body:elm.body,
                    email:'email@gmail.com'
                }))
            ]
            setPosts(data)
        }
        get()
    }, [])

    return (
        <div className='postsBigDiv'>
            <h1>Posts</h1>
            <button className='back' onClick={back}>Back</button>
            {
                posts.map(element =>
                    <div className='postsDiv' key={element.id}>
                        <div className='item' >                                
                            <div style={{
                                display:'flex', 
                                flexDirection:'column', 
                                padding:'10px', 
                                margin:'10px'
                            }}>
                                <h2>{element.id}</h2>
                                <Link to={`${element.id}`}>{element.title}</Link>
                                <p>{element.body}</p>
                                <p>{element.email}</p>
                            </div>
                        </div>
                    </div>
                )
            }
        </div>
    )
}
