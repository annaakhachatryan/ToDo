import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router'
import { Link } from 'react-router-dom'

export const Comments = () => {
    const navigate =useNavigate()

    const [comments, setComments] = useState([])

    useEffect(()=>{
        const getComment = async ()=>{
            const result = await fetch('https://jsonplaceholder.typicode.com/comments?_limit=100')
            const jsonRes = await result.json()

            const data =[
                ...jsonRes.map(item=>({
                    id:item.id,
                    postId:item.PostId,
                    name:item.name,
                    email:item.email,
                    body:item.body,
                }))
            ]
            setComments(data)
        }
        getComment()
    })
    return (
        <div>
            <h1>Comments</h1>
            <button onClick={()=>navigate(-1)} className='back'>Back</button>            
            {
                comments.map(el =>
                    <div className='postsDiv' key={el.id}>
                        <div className='item'>
                            <div style={{
                            display: 'flex',
                            flexDirection: 'column',
                            padding: '10px',
                            margin: '10px',
                        }}>
                            <h1>{el.id}</h1>
                            <Link to={`${el.id}`}>{el.name}</Link>
                            <p>{el.email}</p>
                            <p>{el.body}</p>
                        </div>
                        </div>
                    </div>
                )
            }
        </div>
    )
}
