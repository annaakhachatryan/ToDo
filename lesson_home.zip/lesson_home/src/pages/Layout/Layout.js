import React from 'react'
import { NavLink, Outlet } from 'react-router-dom'

import './Layout.css'

export const Layout = () => {
    return (
        <div>
            <header className='headerLink'>
                <NavLink to='/'>Posts</NavLink>
                <NavLink to='/Photos'>Photos</NavLink>
                <NavLink to='/Comments'>Comments</NavLink>
                <NavLink to='/New'>New Users</NavLink>
            </header>
            <Outlet/>
        </div>
    )
}
