import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

export const ToDos = () => {
    const [toDos, setToDos] = useState([])

    useEffect(() => {
        fetch('https://jsonplaceholder.typicode.com/todos')
            .then(res => res.json())
            .then(data => setToDos(data))
    })
    return (
        <div style=
            {{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexDirection: 'column',
                marginTop: "8vh"
            }}>
            {
                toDos.map(el =>
                    <div className='eachItem' key={el.id}>
                        <div>
                            <h2>{el.id}</h2>
                            <Link to={`${el.id}`}>{el.title}</Link>
                        </div>
                    </div>
                )
            }
        </div>
    )
}
