import React, { useContext } from 'react'
import { ToDoContext } from '../../Context/ToDoContext/ToDoCOntext';

export const ToDO = () => {
    const { state, dispatch } = useContext(ToDoContext)
    const {toDos, text, editItem} = state

    const changeInputValue = (e) =>{
        dispatch({type:'toggleText', payload:e.target.value})
    }

    const handlerSubmitForm = (e) =>{
        e.preventDefault()
        if (!text.trim()) {
            return
        }
        if(editItem){
            dispatch({type:'editEachToDoItem', payload:{
                id:editItem.id,
                title:text,
                isCompleted:editItem.isCompleted
            }})
        dispatch({type:'resetEditToDoItem'})
            return
        }
        dispatch({type:'addToDoItem', payload : text})
        dispatch({type:'resetText'})
    }

    const edit = (toDo) => {
        dispatch({type:'editToDoItem', payload:toDo})
        dispatch({type:'toggleText', payload:toDo.title})
    }

    console.log(editItem);
    console.log(toDos);
    return (
        <div className='bigDiv'>
            <form onSubmit={handlerSubmitForm}>
                <input
                    onChange={changeInputValue}
                    value={text}
                    type="text"
                    placeholder="Add new to do !"
                />
                <button>{editItem ? 'Edit' : 'Add'}</button>
            </form>

            {
                toDos.length === 0 ? (
                    <p className='notHaveToDo'> You do not have TODO !</p>
                ) : (
                    toDos.map((toDo) => (
                        <div className='toDoList' key={toDo.id}>
                            <input className='checkbox' type='checkbox' checked={toDo.isCompleted} onChange={() => dispatch({ 
                                type: 'checkToDoItem', 
                                payload:toDo.id})} />
                            <p className='text'
                            style={{textDecoration: toDo.isCompleted ? 'line-through' : 'none'}}
                            > {toDo.title} </p>
                            <button onClick={()=>dispatch({type:'deleteToDo', payload:toDo.id})}>Delete</button>
                            <button onClick={()=>edit(toDo)}>Edit</button>
                        </div>
                    ))
                )
            }
        </div>
    )
}