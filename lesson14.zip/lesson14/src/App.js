import { ToDoContext } from './Context/ToDoContext/ToDoCOntext';
import './App.css';
import { ToDO } from './Components/ToDo/ToDO';
import { useReducer } from 'react';

const reducer = (state, action) => {
  switch (action.type) {
    case 'toggleText':
      return {
        ...state,
        text: action.payload
      }
    case 'resetText':
      return {
        ...state,
        text: ''
      }
    case 'addToDoItem':
      return {
        ...state,
        toDos: [...state.toDos, {
          id: new Date().getTime().toString(),
          title: action.payload,
          isCompleted: false,
        }]
      }
    case 'deleteToDo':
      return {
        ...state,
        toDos: [...state.toDos.filter(toDo => toDo.id !== action.payload)]
      }
    case 'checkToDoItem':
      return {
        ...state,
        toDos: [...state.toDos.map(toDo => toDo.id === action.payload ? { ...toDo, isCompleted: !toDo.isCompleted } : toDo)]
      }
    case 'editToDoItem':
      return {
        ...state,
        editItem: action.payload
      }
    case 'editEachToDoItem' :
      return {
        ...state,
        toDos:[...state.toDos.map(toDo => toDo.id === action.payload.id ? {...toDo, title:action.payload.title} : toDo)]
      }
    case 'resetEditToDoItem' :
      return{
        ...state,
        editItem:null
      }
    default:
      return state;
  }
}

function App() {
  const [state, dispatch] = useReducer(reducer, {
    toDos: [],
    text: '',
    editItem: null,
  })
  return (
    <div className="App">
      <ToDoContext.Provider value={{ state, dispatch }}>
        <ToDO />
      </ToDoContext.Provider>
    </div>
  );
}

export default App;