import { createStore } from "redux";

const store = createStore((state, action)=>{
    switch (action.type) {
        case 'toggleText':
            return{
                ...state,
                text: action.payload
            }
        case 'resetText' : 
            return {
                ...state,
                text:''
            }
        case 'addToDo' : 
            return {
                ...state,
                toDos:[...state.toDos, {
                    id : new Date().getTime().toString(),
                    title: action.payload,
                    isCompleted: false,
                }]
            }
        case 'deleteToDo' :
            return {
                ...state,
                toDos:[...state.toDos.filter(toDo => toDo.id !== action.payload)]
            }
        case 'checkToDoItem' :
            return {
                ...state,
                toDos:[...state.toDos.map(toDo => toDo.id === action.payload ? {...toDo, isCompleted : !toDo.isCompleted} : toDo)]
            }
        case 'editToDo' : 
            return {
                ...state,
                editToDo:action.payload
            }
        case 'editToDoItems' : 
            return {
                ...state,
                toDos:[...state.toDos.map(toDo => toDo.id === action.payload.id ? {...toDo, title:action.payload.title} : toDo)]
            }
        case 'resetEdit' :
            return {
                ...state,
                editToDo:null
            }
        default:
            return state;
    }
}, {
    text:'',
    toDos:[],
    editToDo:null,
})

export const selectText = (state) => state.text
export const selectToDos = (state) => state.toDos
export const selectEditToDo = (state) => state.editToDo

export const actionToggleText = payload => ({type:'toggleText', payload})
export const actionResetText = () => ({type:'resetText'})
export const actionAddToDo = payload => ({type:'addToDo', payload})
export const actionDeleteToDo = payload => ({type:'deleteToDo', payload})
export const actionCheckToDoItem = payload => ({type:'checkToDoItem', payload})
export const actionEditToDo = payload => ({type:'editToDo', payload})
export const actionEditToDoItems = payload => ({type:'editToDoItems', payload})
export const actionResetEdit = payload => ({type:'resetEdit', payload})


export default store