import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { 
    actionAddToDo, 
    actionCheckToDoItem, 
    actionDeleteToDo, 
    actionEditToDoItems, 
    actionResetEdit, 
    actionResetText, 
    actionToggleText, 
    selectEditToDo, 
    selectText, 
    selectToDos 
} from '../../store/store'

export const ToDo = () => {
    const text = useSelector(selectText)
    const toDos = useSelector(selectToDos)
    const editToDo = useSelector(selectEditToDo)

    const dispatch = useDispatch()

    const handlerSubmitForm = (e) =>{
        e.preventDefault()
        if(!text.trim()) {return}

        if(editToDo){
            dispatch(actionEditToDoItems({
                id:editToDo.id,
                title:text,
                isCompleted:editToDo.isCompleted
            }))
            dispatch(actionResetEdit())
            return
        }
        dispatch(actionAddToDo(text))
        dispatch(actionResetText())
    }

    const editToDoItems = (toDo) => {
        dispatch(actionAddToDo(toDo))
        dispatch(actionToggleText(toDo.title))
    }

    console.log(toDos);
    console.log(text);
    return (
        <div className='toDo'>
            <form onSubmit={handlerSubmitForm}>
                <input value={text} onChange={(e)=>dispatch(actionToggleText(e.target.value))} type='text' placeholder='Add ToDo !' />
                <button>{editToDo ? 'Edit' : 'Add'}</button>
            </form>
            {
                toDos.length === 0 ? 
                    (<h2 style={{margin:'0 20px'}}>You do not have ToDo!</h2>) 
                    :
                    (
                        toDos.map(toDo => (
                            <div className='toDoList' key={toDo.id}>
                                <div className='eachItem'>
                                    <input className='checkbox'
                                        type='checkbox'
                                        checked={toDo.isCompleted}
                                        onChange={() => dispatch(actionCheckToDoItem(toDo.id))}
                                    />
                                    <p className='text'
                                        style={{ textDecoration: toDo.isCompleted ? 'line-through' : 'none' }}
                                    > {toDo.title} </p>
                                    <div>
                                        <button onClick={() => dispatch(actionDeleteToDo(toDo.id))}>Delete</button>
                                        <button>Edit</button>
                                    </div>
                                </div>
                            </div>
                        ))
                    )
            }
        </div>
    )
}
