import React, { useContext, useState } from 'react'
import { ToDoContext } from '../../Context/ToDoContext/ToDoCOntext';

export const ToDO = () => {
    const { state, dispatch } = useContext(ToDoContext)
    const [text, setText] = useState("");

    const handleDelete = id => {
        dispatch({ type: "delete", payload: id });
    };
    console.log(state);

    const addNewToDo = () => {
        dispatch({
            type: "addToDo",
            payload: {
                id: new Date().getTime().toString(),
                text,
            }
        })
        setText("");
    };
    

    return (
        <div className='bigDiv'>
            <input
                type="text"
                value={text}
                onChange={e => setText(e.target.value)}
                placeholder="Add new to do !"
            />
            <button onClick={addNewToDo}>Add</button>

            {
                state.todo.length === 0 ? (
                    <p className='notHaveToDo'> You do not have TODO !</p>
                ) : (
                    state.todo.map((toDo, id) => (
                        <div className='toDoList' key={toDo.id}>
                            <p className='text' style={{textDecoration: toDo.completed ? "line-through red" : ''}} 
                                    onClick={() => dispatch({type:'toggleToDo', id})}>
                                {toDo.text}
                            </p>
                            <button onClick={() => handleDelete(toDo.id)}>Delete</button>
                        </div>
                    ))
                )
            }
        </div>
    )
}