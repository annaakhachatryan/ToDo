import { ToDoContext } from './Context/ToDoContext/ToDoCOntext';
import './App.css';
import { ToDO } from './Components/ToDo/ToDO';
import { useReducer } from 'react';

export const toDos = {
  todo: []
};
const reducer = (state, action) => {
  switch (action.type) {
    case "addToDo":
      return {
        todo: [
          ...state.todo,
          action.payload
        ]
      };
    case 'toggleToDo':
      return {
        todo: state.todo.map((todo, id) =>
          id === action.id
            ? { 
              ...todo, 
              completed : !todo.completed 
              }
            : todo,
        ),
      };
    case "delete":
      return {
        todo: [
          ...state.todo.filter(item => item.id !== action.payload)
        ]
      };
    default:
      return state;
  }

}

function App() {
  const [state, dispatch] = useReducer(reducer, toDos)
  return (
    <div className="App">
      <ToDoContext.Provider value={{ state, dispatch }}>
        <ToDO />
      </ToDoContext.Provider>
    </div>
  );
}

export default App;
